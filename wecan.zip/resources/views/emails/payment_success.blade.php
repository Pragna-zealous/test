<!DOCTYPE html>
<html>
<head>
    <title>Payment Success Email</title>
</head>

<body>
<h2>Hello {{$user['name']}},</h2>
<br/>
Thank You for Donating.

</body>

</html>