@extends('layouts.app_front')

@section('content')
<div class="homepage">
	<h1>Thank You For Donation !</h1>
</div>

@endsection