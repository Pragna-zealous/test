<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Welcome to the site {{$user['name']}}</h2>
<br/>
Your registered email-id is {{$user['email']}}
Your login credentials are as below:
Email Address: {{$user['email']}}
Password: {{$password}}

please click on below link to activate your account.

</body>

</html>