@extends('layouts.app_front')

@section('content')
  
    <div class="container">
	    <div class="row">
		    <div class="col-md-12">
		    	<div class="homepage">
		    		<h1>Homepage Coming Soon... </h1>
		    	</div>
		    </div>
	    </div>
    </div>
       
@endsection